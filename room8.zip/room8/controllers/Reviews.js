class ControllerReviews {
  create(rating, comment) {}
  read(id) {}
  update(id, rating, comment) {}
  delete(id) {}
}
