class ControllerMessages {
  messages = [];

  create(text) {}
  read(id) {}
  update(id, text) {}
  delete(id) {}
}
