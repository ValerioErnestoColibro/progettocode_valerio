class ControllerUserReviews {
  create(idUser, idReview) {}
  read(id) {}
  update(id, idUser, idReview) {}
  delete(id) {}
}
