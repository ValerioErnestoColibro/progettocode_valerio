class ModelUserReview {
  constructor(idUser, idReview) {
    this.idUser = idUser;
    this.idReview = idReview;
  }
}
