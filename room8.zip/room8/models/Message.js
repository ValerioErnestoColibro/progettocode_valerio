class ModelMessage {
  constructor(text) {
    this.id = Math.random();
    this.text = text;
  }
}
