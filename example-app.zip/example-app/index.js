const App = require("./App.js");

const app = new App();
app.signup("alice", "123", "alice@wind,it");
