class ControllerUserReviews {
  #userReviews = [];

  create(idUser, idReview) {
    const userReview = {
      id: Math.random(),
      idUser,
      idReview,
    };

    this.#userReviews.push(userReview);
    return userReview;
  }
  read(id) {}
  update(id, idUser, idReview) {}
  delete(id) {}
}
