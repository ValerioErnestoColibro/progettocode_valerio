class ControllerReviews {
  reviews = [];

  create(rating, comment) {
    const review = {
      id: Math.random(),
      rating,
      comment,
    };

    this.reviews.push(review);
    return review;
  }
  read(id) {}
  update(id, rating, comment) {}
  delete(id) {}
}

module.exports = ControllerReviews;
