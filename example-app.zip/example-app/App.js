const ControllerUsers = require("./controllers/Users.js");
const ControllerReviews = require("./controllers/Reviews.js");
const ControllerUsersReviews = require("./controllers/UserReviews.js");

class App {
  #users = new ControllerUsers();
  #reviews = new ControllerReviews();
  #usersReviews = new ControllerUsersReviews();
  #auth = null;

  signup(username, password, email) {
    if (!this.#auth) {
      const userCreated = this.#users.create(username, password, email);
      console.log(userCreated);
    } else console.log("You are already logged in");
  }

  login(username, password) {
    if (!this.#auth) {
      const user = this.#users.read(username, password);
      if (!!user) {
        this.#auth = user;
        console.log("You are logged in");
      } else console.log("Invalid credentials");
    } else console.log("You are already logged in");
  }

  writeReview(rating, comment) {
    if (!!this.#auth) {
      const reviewCreated = this.#reviews.create(rating, comment);
      const value = this.#usersReviews.create(this.#auth.id, reviewCreated.id);
    } else console.log("You must be logged in to write a review");
  }
}

module.exports = App;
