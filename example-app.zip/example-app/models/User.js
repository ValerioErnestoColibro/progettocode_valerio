class ModelUser {
  constructor(username, password, email) {
    this.id = Math.random();
    this.username = username;
    this.password = password;
    this.email = email;
  }
}

module.exports = ModelUser;
